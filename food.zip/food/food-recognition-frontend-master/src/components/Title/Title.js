import React from 'react';

const Title = () => {
  return (
    <div>
      <div className='white f1'>
        {'SMART BRAIN - FOOD RECOGNITION'}
      </div>
    </div>
  );
}

export default Title;